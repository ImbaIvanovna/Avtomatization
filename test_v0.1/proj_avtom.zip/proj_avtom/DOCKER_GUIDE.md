# 🐳 Руководство по работе с Docker

## 📋 Обзор

Ваш музыкальный магазин полностью контейнеризован и готов к работе в Docker. Проект включает:

- **Dockerfile** - образ приложения на базе Python 3.11 Alpine
- **docker-compose.yml** - production конфигурация с nginx
- **docker-compose.dev.yml** - development конфигурация с hot reload
- **nginx.conf** - настройки reverse proxy и статических файлов

## 🚀 Быстрый старт

### 1. Production режим (рекомендуется)
```bash
# Сборка и запуск
docker-compose up --build

# В фоновом режиме
docker-compose up -d --build
```

**Приложение будет доступно:**
- Прямо через Flask: http://localhost:5000
- Через nginx: http://localhost:80

### 2. Development режим (с hot reload)
```bash
# Запуск с автоматической перезагрузкой
docker-compose -f docker-compose.dev.yml up --build

# В фоновом режиме
docker-compose -f docker-compose.dev.yml up -d --build
```

### 3. Только Flask (без nginx)
```bash
# Запуск только веб-приложения
docker-compose up web

# В фоновом режиме
docker-compose up -d web
```

## 📁 Структура проекта

```
proj_avtom/
├── Dockerfile                 # Образ приложения
├── docker-compose.yml         # Production конфигурация
├── docker-compose.dev.yml     # Development конфигурация
├── nginx.conf                 # Настройки nginx
├── .dockerignore             # Исключения для сборки
├── data/                     # Персистентные данные (база данных)
├── logs/                     # Логи приложения
├── static/                   # Статические файлы
├── templates/                # HTML шаблоны
├── app.py                    # Основное приложение
├── database.py               # Инициализация БД
└── requirements.txt          # Python зависимости
```

## 🔧 Управление контейнерами

### Основные команды
```bash
# Просмотр статуса
docker-compose ps

# Просмотр логов
docker-compose logs -f

# Логи только веб-сервиса
docker-compose logs -f web

# Перезапуск сервиса
docker-compose restart web

# Остановка всех сервисов
docker-compose down

# Остановка с удалением volumes (ОСТОРОЖНО!)
docker-compose down -v
```

### Работа с образами
```bash
# Пересборка образа
docker-compose build --no-cache

# Удаление неиспользуемых образов
docker system prune -a

# Просмотр образов
docker images
```

### Доступ к контейнеру
```bash
# Выполнение команд в контейнере
docker-compose exec web bash

# Выполнение одной команды
docker-compose exec web python -c "print('Hello from container')"

# Просмотр файлов в контейнере
docker-compose exec web ls -la /app
```

## 🗄️ Работа с данными

### База данных
```bash
# Инициализация базы данных
docker-compose exec web python database.py

# Просмотр базы данных
docker-compose exec web sqlite3 data/music_store.db

# SQL запросы
docker-compose exec web sqlite3 data/music_store.db "SELECT * FROM users;"
```

### Резервное копирование
```bash
# Создание бэкапа базы данных
docker-compose exec web cp data/music_store.db data/music_store_backup_$(date +%Y%m%d).db

# Копирование бэкапа на хост
docker cp $(docker-compose ps -q web):/app/data/music_store.db ./backup.db
```

## 🌐 Сетевая конфигурация

### Порты
- **5000** - Flask приложение
- **80** - nginx (если включен)

### Изменение портов
Отредактируйте `docker-compose.yml`:
```yaml
ports:
  - "8080:5000"  # Flask на порту 8080
  - "8081:80"    # nginx на порту 8081
```

## ⚙️ Переменные окружения

### Создание .env файла
```bash
# Создайте файл .env в корне проекта
cat > .env << EOF
SECRET_KEY=your-very-secret-key-here
FLASK_ENV=production
DATABASE_PATH=/app/data/music_store.db
EOF
```

### Безопасность
⚠️ **Важно для production:**
1. Смените `SECRET_KEY` на случайную строку
2. Используйте HTTPS в production
3. Настройте firewall
4. Регулярно обновляйте базовый образ

## 📊 Мониторинг

### Health checks
```bash
# Проверка здоровья контейнера
docker-compose ps

# Детальная информация о контейнере
docker inspect $(docker-compose ps -q web)
```

### Логи
```bash
# Все логи
docker-compose logs

# Логи с фильтрацией
docker-compose logs | grep ERROR

# Логи за последний час
docker-compose logs --since 1h
```

### Ресурсы
```bash
# Использование ресурсов
docker stats $(docker-compose ps -q)

# Детальная статистика
docker-compose exec web top
```

## 🔄 Обновление приложения

### Обновление кода
```bash
# 1. Остановите контейнеры
docker-compose down

# 2. Обновите код (git pull, редактирование файлов)

# 3. Пересоберите и запустите
docker-compose up --build -d
```

### Обновление зависимостей
```bash
# 1. Обновите requirements.txt

# 2. Пересоберите образ
docker-compose build --no-cache

# 3. Перезапустите
docker-compose up -d
```

## 🚨 Troubleshooting

### Проблемы с портами
```bash
# Проверка занятых портов
netstat -tulpn | grep :5000
netstat -tulpn | grep :80

# Освобождение порта
sudo fuser -k 5000/tcp
```

### Проблемы с правами доступа
```bash
# Исправление прав на директории
sudo chown -R $USER:$USER data/ logs/
chmod -R 755 data/ logs/
```

### Проблемы с сетью Docker
```bash
# Перезапуск Docker daemon
sudo systemctl restart docker

# Очистка сети Docker
docker network prune
```

### Проблемы с базой данных
```bash
# Пересоздание базы данных
docker-compose down
rm -rf data/
docker-compose up --build -d
```

### Проблемы с памятью
```bash
# Очистка неиспользуемых ресурсов
docker system prune -a --volumes

# Проверка использования диска
docker system df
```

## 📈 Масштабирование

### Горизонтальное масштабирование
```bash
# Запуск нескольких экземпляров
docker-compose up --scale web=3

# С nginx в качестве load balancer
docker-compose --profile with-nginx up --scale web=3
```

### Оптимизация производительности
```yaml
# В docker-compose.yml увеличьте лимиты ресурсов
deploy:
  resources:
    limits:
      memory: 1G
      cpus: '1.0'
```

## 🔐 Безопасность

### Рекомендации
1. **Используйте non-root пользователя** (уже настроено)
2. **Ограничьте ресурсы** (уже настроено)
3. **Используйте secrets для паролей**
4. **Регулярно обновляйте базовые образы**
5. **Настройте firewall**

### Пример с secrets
```yaml
# docker-compose.yml
secrets:
  secret_key:
    file: ./secrets/secret_key.txt

services:
  web:
    secrets:
      - secret_key
    environment:
      - SECRET_KEY_FILE=/run/secrets/secret_key
```

## 📞 Поддержка

При возникновении проблем:

1. **Проверьте логи:** `docker-compose logs`
2. **Проверьте статус:** `docker-compose ps`
3. **Проверьте ресурсы:** `docker stats`
4. **Перезапустите:** `docker-compose restart`

### Полезные команды для диагностики
```bash
# Информация о системе
docker system info

# Информация о контейнере
docker-compose exec web env

# Проверка сети
docker network ls
docker network inspect proj_avtom_default
```

---

## 🎵 Готово к использованию!

Ваш музыкальный магазин теперь полностью контейнеризован и готов к развертыванию в любой среде, поддерживающей Docker!
