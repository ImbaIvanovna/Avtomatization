# 🗄️ Устранение проблем с базой данных

## ❌ Проблема: Пользователи не сохраняются после перезапуска

### Причина:
База данных удалялась при каждом запуске контейнера из-за функции `init_database()`.

### ✅ Решение:
Проблема исправлена! Теперь база данных сохраняется между перезапусками.

## 🔧 Управление базой данных

### Проверка статуса базы данных:
```bash
# В контейнере
docker-compose exec web python manage_db.py status

# Или локально
python manage_db.py status
```

### Инициализация базы данных (только если не существует):
```bash
# В контейнере
docker-compose exec web python manage_db.py init

# Или локально
python manage_db.py init
```

### Пересоздание базы данных (удалить все данные):
```bash
# В контейнере
docker-compose exec web python manage_db.py recreate

# Или локально
python manage_db.py recreate
```

## 📁 Структура данных

### Важные папки:
- **`./data/`** - база данных SQLite (персистентная)
- **`./logs/`** - логи приложения

### Проверка монтирования volumes:
```bash
# Проверить, что папка data монтируется
docker-compose exec web ls -la /app/data/

# Проверить содержимое базы данных
docker-compose exec web sqlite3 /app/data/music_store.db "SELECT * FROM users;"
```

## 🚨 Если проблема все еще есть

### 1. Проверьте права доступа:
```bash
# Создать папку data с правильными правами
mkdir -p data
chmod 755 data

# Проверить права
ls -la data/
```

### 2. Проверьте монтирование в контейнере:
```bash
# Зайти в контейнер
docker-compose exec web bash

# Проверить содержимое папки
ls -la /app/data/

# Проверить переменную окружения
echo $DATABASE_PATH
```

### 3. Принудительное пересоздание:
```bash
# Остановить контейнеры
docker-compose down

# Удалить папку data (ОСТОРОЖНО - удалит все данные!)
rm -rf data/

# Запустить заново
docker-compose up -d
```

## 📊 Мониторинг базы данных

### Просмотр пользователей:
```bash
docker-compose exec web sqlite3 /app/data/music_store.db "SELECT id, username, role FROM users;"
```

### Просмотр всех таблиц:
```bash
docker-compose exec web sqlite3 /app/data/music_store.db ".tables"
```

### Резервное копирование:
```bash
# Создать бэкап
docker-compose exec web cp /app/data/music_store.db /app/data/music_store_backup.db

# Скопировать на хост
docker cp $(docker-compose ps -q web):/app/data/music_store.db ./backup.db
```

## ✅ Проверка работоспособности

1. **Запустите контейнер:**
   ```bash
   docker-compose up -d
   ```

2. **Добавьте пользователя через веб-интерфейс**

3. **Остановите контейнер:**
   ```bash
   docker-compose down
   ```

4. **Запустите снова:**
   ```bash
   docker-compose up -d
   ```

5. **Проверьте, что пользователь сохранился**

Если пользователь сохранился - проблема решена! 🎉
